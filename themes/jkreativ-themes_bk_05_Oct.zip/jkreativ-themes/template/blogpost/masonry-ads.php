<div class="article-masonry-container">
	<article class="article-masonry-box">
		<div class="article-masonry-wrapper article-masonry-box-ads clearfix">
			<div class="article-masonry-ads-text"><?php _e('Advertisement','jeg_textdomain'); ?></div>
			<a href="<?php echo vp_metabox('jkreativ_blog_ads.ads_url'); ?> ">
				<div class="dummy-image">
					<img src="<?php echo jeg_get_image_attachment(vp_metabox('jkreativ_blog_ads.image')); ?> "/>
				</div>
			</a>
		</div>
	</article>
</div>