<?php
/** 
Template Name: Fullscreen (Slider) - Kenburn Slider
 */
 
get_header();

if ( ! post_password_required() ) 
{
?>
<div class="headermenu">
	<?php jeg_get_template_part('template/rightheader'); ?>
</div> <!-- headermenu -->



<!-- begin IOS Slider -->
<div class="fs-container kenburnslider">
	<div id="kenburns-slideshow"></div>
	<div class="kenburntext">
		<?php 
			$slideritem = vp_metabox('jkreativ_page_fsslider_content.slideritem');
			foreach($slideritem as $id => $slider) {
				echo "<div class='kenburntextcontent ioscontainer item'>";
					echo "<div class='text1'>" . do_shortcode($slider['firstline']) . "</div>\n";
					if($slider['secondline']) {
						echo "<div class='text2'>{$slider['secondline']}</div>\n";
					}
					if($slider['show_thirdline']) {
						echo "<div class='text3'><a class='slider-button' href='{$slider['buttonurl']}'><span class='button-text'>{$slider['buttontext']}</span></a></div>\n";
					}
				echo "</div>\n";
			} 
		?>			
	</div>
	<div class="kennav">
		<ul>
			<?php
				foreach($slideritem as $id => $slider) {
					echo "<li data-seq='$id'>" . ( $id + 1 ) . "</li>";
				}
			?>			
		</ul>
	</div>
</div>
<div class="sliderloader bigloader"></div>	

<?php 
	$sliderimage = array();
	$slideroverlay = array();
	
	foreach($slideritem as $id => $slider) {
		$sliderimage[] = jeg_get_image_attachment($slider['background']);
		$slideroverlay[] = $slider['overlay_color'];
	}
?>

<script>
	(function($){
		$(document).ready(function(){
			/** Full screen **/
			if($(".fs-container").length) {
				$(".fs-container").fsfullheight(['.headermenu', '.responsiveheader', '.topnavigation']);
				$(".sliderloader").show();	
			}
			var resizetimeout = null;
			
			/** Kenburn slider **/	
			var recreate_slider = function(){
				$('#kenburns-slideshow').Kenburns({
			    	images: <?php echo json_encode($sliderimage); ?>,
			    	overlay: <?php echo json_encode($slideroverlay) ?>,
			    	scale: <?php echo vp_metabox('jkreativ_page_kenburn.zoom') ?>,
			    	duration:<?php echo vp_metabox('jkreativ_page_kenburn.displaytime'); ?>,
			    	fadeSpeed:<?php echo vp_metabox('jkreativ_page_kenburn.fadetime') ?>,
			    	ease3d:'cubic-bezier(0, 0, 0, 0)',
			    	onSlideComplete: function(){},
			    	onLoadingComplete: function(){
			    		$(".bigloader").fadeOut();
			    		$(".kennav").fadeIn();
			    	}
			    });
			};
																									
			$(window).bind(' load', function(){
				clearTimeout(resizetimeout);
				resizetimeout = setTimeout(function(){
					recreate_slider();
				}, 250); 
			});
		});		
	})(jQuery);
</script>				        		
<!-- end IOS Slider -->



<?php
} else {
    jeg_get_template_part('template/password-form');
} 

get_footer(); 
?>