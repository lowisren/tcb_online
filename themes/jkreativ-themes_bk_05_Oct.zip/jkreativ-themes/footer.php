							</div> <!-- .content -->
						</div> <!-- contentholder -->
					</div> <!-- #rightsidecontainer -->
				</div> <!-- .containerwrapper -->
	        	<div class="contentoverflow"></div> 
			</div> <!-- .container -->
 		</div> <!-- .jviewport --> 		 				
		<?php get_template_part('template/rightclickoverlay'); ?>
		<?php get_template_part('template/musicbackground') ?>

	<?php wp_footer() ?>

	<!-- Facebook Conversion Code for Faceboon Ads -->
<script>(function() {
  var _fbq = window._fbq || (window._fbq = []);
  if (!_fbq.loaded) {
    var fbds = document.createElement('script');
    fbds.async = true;
    fbds.src = '//connect.facebook.net/en_US/fbds.js';
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(fbds, s);
    _fbq.loaded = true;
  }
})();
window._fbq = window._fbq || [];
window._fbq.push(['track', '6020497743306', {'value':'0.00','currency':'SGD'}]);
</script>
<noscript><img height="1" width="1" alt="" style="display:none" src="https://www.facebook.com/tr?ev=6020497743306&amp;cd[value]=0.00&amp;cd[currency]=SGD&amp;noscript=1" /></noscript>

<!--  google analytic  -->
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
 
  ga('create', 'UA-30474123-1', 'auto');
  ga('send', 'pageview');
 
</script>

	</body>
</html>