<div class="mobile-main-menu mobile-menu-content">
    <h2><?php _e('Menu', 'jeg_textdomain'); ?></h2>
    <?php jeg_mobile_navigation(); ?>
</div>