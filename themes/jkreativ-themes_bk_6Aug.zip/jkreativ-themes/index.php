<?php
/** 
 * this is last file that will execute if none of any file match with page defined
 * primary usage is for blog page
 * 
 * @author Jegbagus
 */
get_template_part('template/template-blog');
