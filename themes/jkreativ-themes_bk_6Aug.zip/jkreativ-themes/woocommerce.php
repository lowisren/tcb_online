<?php get_header(); ?>
<div class="headermenu">
	<?php get_template_part('template/rightheader'); ?>
</div> <!-- headermenu -->
<?php 
	jeg_woocommerce_content();
	get_footer(); 
?>