<?php
/**
* Force Visual Composer to initialize as "built into the theme". This will hide certain tabs under the Settings->Visual Composer page
*/
if(function_exists('vc_set_as_theme')) {
    vc_set_as_theme();
}

/* visual composer integration */
function jeg_vc_update(){
    if (class_exists('WPBakeryVisualComposerAbstract')) {
        require_once get_template_directory() . '/admin/vc/extend.php';
        require_once get_template_directory() . '/admin/vc/view.php';
        require_once get_template_directory() . '/admin/vc/element.php';
        vc_set_default_editor_post_types(array('page', 'portfolio'));
    }
}

add_action( 'init' ,  'jeg_vc_update' , 2 );

